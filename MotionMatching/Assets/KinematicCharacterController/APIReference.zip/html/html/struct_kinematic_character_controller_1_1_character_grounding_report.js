var struct_kinematic_character_controller_1_1_character_grounding_report =
[
    [ "CopyFrom", "struct_kinematic_character_controller_1_1_character_grounding_report.html#ad49b2e9a45235821fc4342b695a858a1", null ],
    [ "FoundAnyGround", "struct_kinematic_character_controller_1_1_character_grounding_report.html#a97f0639e2282e736ba708000bea39054", null ],
    [ "GroundCollider", "struct_kinematic_character_controller_1_1_character_grounding_report.html#a1c88fe2ad00119fb31fc9ec2c48d7bba", null ],
    [ "GroundNormal", "struct_kinematic_character_controller_1_1_character_grounding_report.html#a9cd4f214a507d4ade295e7a6c1f306a7", null ],
    [ "GroundPoint", "struct_kinematic_character_controller_1_1_character_grounding_report.html#a3c57ed8e2f83bb6c61b4c7bcb67bce74", null ],
    [ "InnerGroundNormal", "struct_kinematic_character_controller_1_1_character_grounding_report.html#a6bd537e050cac171dc856630f8eed44d", null ],
    [ "IsStableOnGround", "struct_kinematic_character_controller_1_1_character_grounding_report.html#a1169e334828e63d6b29688877881e036", null ],
    [ "OuterGroundNormal", "struct_kinematic_character_controller_1_1_character_grounding_report.html#a68aad59974a67d08ee30b1372c7257b8", null ],
    [ "SnappingPrevented", "struct_kinematic_character_controller_1_1_character_grounding_report.html#a4fe57bfee8d05a8166400fb51e2f75ed", null ]
];